<?php

$con=mysqli_connect("localhost","sleekwav_user","Merapi14","sleekwav_kec");


$NamaD           	= $_POST['NamaD'];
$password        	= $_POST['password'];
$birthday     	= $_POST['birthday'];
$gender				= $_POST['gender'];
$email            = $_POST['email'];
$phone				= $_POST['phone'];
$kelurahan			= $_POST['kelurahan'];


$query = mysqli_query($con, "INSERT INTO masyarakat_account (NamaD, password, birthday, gender, email, phone, kelurahan) VALUES ('$NamaD', '$password', '$birthday', '$gender', '$email', '$phone', '$kelurahan')");


if ($query){

    echo "<script>alert('Pendaftaran Akun Berhasil! Silahkan Login Kembail'); window.location = 'index.html'</script>";	
} else {
	echo "<script>alert('Pendaftaran Akun Gagal! Periksa Kembali Data Anda!'); window.location = 'edit.php?hal=edit&kd='reg.html'</script>";
    }
?>
