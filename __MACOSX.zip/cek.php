<?php


$email = $_POST['email'];
$password = $_POST['password'];

$con=mysqli_connect("localhost","sleekwav_user","Merapi14","sleekwav_kec");

$query = mysqli_query($con, "SELECT COUNT(email) AS jumlah FROM masyarakat_account 
					WHERE email='$email' AND password='$password'");
$data = mysqli_fetch_array($query);

if ($data['jumlah'] >= 1){

	header('location:login/index.php');	
} else {
	header('location:index.html');	
}
?>