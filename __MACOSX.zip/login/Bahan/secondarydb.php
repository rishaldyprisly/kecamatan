<?php
$host = "localhost";
$user = "sparksid_7rishy";
$pass = "!Merapi14!";
$database = "sparksid_rishy";

$db = mysqli_connect($host, $user, $pass, $database)or die("FAIL");

?>