<?php
$host = "localhost";
$user = "sparksid_mainai";
$pass = "!Merapi14!";
$database = "sparksid_mainai";

$db = mysqli_connect($host, $user, $pass, $database)or die("FAIL");

function format_rupiah($rp) {
	$hasil = "Rp." . number_format($rp, 0, "", ".") . ",00";
	return $hasil;
}
?>