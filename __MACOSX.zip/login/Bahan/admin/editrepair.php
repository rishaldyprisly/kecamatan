<?php 
session_start();
if (empty($_SESSION['username'])){
	echo "<script>alert('Selamat Datang.'); window.location = '../index.html'</script>";	
} else {
	include "../koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Aplikasi Penggajian Karyawan">
    <meta name="author" content="sanny sahara">

    <title>Main Control AI System</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <!-- Page Specific CSS -->
    <link rel="stylesheet" href="http://cdn.oesmith.co.uk/morris-0.4.3.min.css">
    
    <script type="text/javascript">
// 1 detik = 1000
window.setTimeout("waktu()",1000);  
function waktu() {   
	var tanggal = new Date();  
	setTimeout("waktu()",1000);  
	document.getElementById("output").innerHTML = tanggal.getHours()+":"+tanggal.getMinutes()+":"+tanggal.getSeconds();
}
</script>
<script language="JavaScript">
var tanggallengkap = new String();
var namahari = ("Minggu Senin Selasa Rabu Kamis Jumat Sabtu");
namahari = namahari.split(" ");
var namabulan = ("Januari Februari Maret April Mei Juni Juli Agustus September Oktober November Desember");
namabulan = namabulan.split(" ");
var tgl = new Date();
var hari = tgl.getDay();
var tanggal = tgl.getDate();
var bulan = tgl.getMonth();
var tahun = tgl.getFullYear();
tanggallengkap = namahari[hari] + ", " +tanggal + " " + namabulan[bulan] + " " + tahun;

	var popupWindow = null;
	function centeredPopup(url,winName,w,h,scroll){
	LeftPosition = (screen.width) ? (screen.width-w)/2 : 0;
	TopPosition = (screen.height) ? (screen.height-h)/2 : 0;
	settings ='height='+h+',width='+w+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',resizable'
	popupWindow = window.open(url,winName,settings)
}
</script>
    
  </head>
  <body>
    <div id="wrapper">

      <!-- Sidebar -->
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.html">Main Control AI System PT.Mitra Prima Motor</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav side-nav">
          <img src="3.png" alt="right" />
            <li class="active"><a href="index.php"><i class="fa fa-dashboard"></i> Manual Mode</a></li>
            <li><a href="status.php"><i class="fa fa-bar-chart-o"></i> Status and Condition</a></li>
            <li><a href="stock.php"><i class="fa fa-table"></i> Stock Lists</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-caret-square-o-down"></i> Information <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="info/info.html" target="_blank">Customer Special Offer</a></li>
                <li><a href="info/holiday.html" target="_blank">Holiday Time</a></li>
                <li><a href="info/meeting.html" target="_blank">Special Meeting</a></li>
                <li><a href="prototype.sparkintech.com" target="_blank">Massive Broadcast</a></li>
              </ul>
            </li>
          </ul>

          <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown user-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i>
              <?php
              echo $_SESSION['username'];
               ?>
              <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#"><i class="fa fa-user"></i> Profil</a></li>
                <li><a href="http://sparks.id/webmail"><i class="fa fa-envelope"></i> Webmail <span class="badge">Login</span></a></li>
                <li><a href="http://sparks.id/cpanel"><i class="fa fa-gear"></i> Login Server </a></li>
                <li class="divider"></li>
                <li><a href="../logout.php" onclick="return confirm('Apakah anda akan keluar?');"><i class="fa fa-power-off"></i> Keluar</a></li>
              </ul>
            </li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </nav>
      
<?php } ?>
      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Main Control AI System<small>PT. Mitra Prima Motor</small></h1>
            <ol class="breadcrumb">
              <li class="active"><i class="fa fa-dashboard"></i> Dashboard</li>
            </ol>
            <table width="900">
            <tr>
            <td width="250"><div class="Tanggal"><h4><script language="JavaScript">document.write(tanggallengkap);</script></div></h4></td> 
            <td align="left" width="30"> - </td>
            <td align="left" width="620"> <h4><div id="output" class="jam" ></div></h4></td>
            </tr>
            </table>
            <br />
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          </div>
        </div>
        <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Edit Customer's Data </h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
                  <?php
$con=mysqli_connect("localhost","sparksid_mainai","!Merapi14!","sparksid_mainai");
                  
$query = mysqli_query($con, "SELECT repairdata.cid, repairdata.vehicle, repairdata.year, repairdata.power, repairdata.color, repairdata.rep, repairdata.status, repairdata.date, repairdata.time, customer.name, customer.phone FROM repairdata, customer WHERE repairdata.cid='$_GET[kd]'");
$data  = mysqli_fetch_array($query);

$query2 = mysqli_query($con, "SELECT * FROM customer WHERE customer.cid='$_GET[kd]'");
$data2  = mysqli_fetch_array($query2);
                    ?>

    <form action="updaterepair.php" method="post">
    <table class="table table-condensed">
        
    <tr>
        <td><label for="cid">Customer ID</label></td>
        <td><input name="cid" type="text" class="form-control" id="cid" value="<?php echo $data['cid'];?>"  readonly="readonly"/></td>
      </tr>
      
       <tr>
        <td><label for="vehicle">Vehicle</label></td>
        <td><input name="vehicle" type="text" class="form-control" id="vehicle" value="<?php echo $data['vehicle'];?>"  readonly="readonly"/></td>
      </tr>
      
       <tr>
        <td><label for="year">Year</label></td>
        <td><input name="year" type="text" class="form-control" id="year" value="<?php echo $data['year'];?>"  readonly="readonly"/></td>
      </tr>
      
       <tr>
        <td><label for="power">Power</label></td>
        <td><input name="power" type="text" class="form-control" id="power" value="<?php echo $data['power'];?>"  readonly="readonly"/></td>
      </tr>
       <tr>
        <td><label for="color">Color</label></td>
        <td><input name="color" type="text" class="form-control" id="color" value="<?php echo $data['color'];?>"  readonly="readonly"/></td>
      </tr>
     
      <tr>
        <td><label for="rep">Replacement</label></td>
        <td><input name="rep" type="text" class="form-control" id="rep" value="<?php echo $data['rep'];?>"  required/></td>
      </tr>
      </tr>
      <tr>
       
        <td><label for="status">Vehicle</label></td>
        <td><select name="status" name="status" id="status" class="form-control" required>
<option></option>
<option value="On Queue"> On Queue</option>
<option value="On Process">On Process</option>
<option value="Washing">Washing</option>
<option value="Ready">Ready</option>
</select></td>
      </tr> 
      <tr>
        <td><label for="owner">Owner</label></td>
        <td><input name="owner" type="text" class="form-control" id="owner" value="<?php echo $data2['name'];?>" readonly="readonly"/></td>
      </tr>
      <tr>
        <td><label for="phone">Phone Number</label></td>
        <td><input name="phone" type="text" class="form-control" id="phone" value="<?php echo $data2['phone'];?>" readonly="readonly"/></td>
      </tr> 
      
      <tr>
        <td><label for="date">Date Entered</label></td>
        <td><input name="date" type="text" class="form-control" id="date" value="<?php echo $data2['date']; ?>" readonly="readonly"/></td>
      </tr>
      <tr>
        <td><label for="time">Time Entered</label></td>
        <td><input name="time" type="text" class="form-control" id="time" value="<?php echo $data['time'];?>" readonly="readonly"/></td>
      </tr>
      <tr>
        <td><input type="submit" value="Simpan Data"  class="btn btn-sm btn-primary"/>&nbsp;<a href="index.php" class="btn btn-sm btn-primary">Back</a>&nbsp;</td>
        </tr>
    </table>
    </form>
                   </div>
                <div class="text-right">
                  <a href="#"  data-toggle="tooltip" class="tip-bottom" data-original-title="Tooltip Dibawah">View All Transactions <i class="fa fa-arrow-circle-right"></i></a>
              
                </div>
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 
      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

    <!-- Page Specific Plugins -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="js/morris/chart-data-morris.js"></script>
    <script src="js/tablesorter/jquery.tablesorter.js"></script>
    <script src="js/tablesorter/tables.js"></script>

  </body>
</html>
