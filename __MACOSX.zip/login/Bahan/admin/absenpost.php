<?php
include "../koneksi.php";
$jan            = $_POST['jan'];
$feb            = $_POST['feb'];
$mar 		    = $_POST['mar'];
$apr 	        = $_POST['apr'];
$mei	        = $_POST['mar'];
$jun	     	= $_POST['jun'];
$jul	        = $_POST['jul'];
$aug	        = $_POST['aug'];
$sep			= $_POST['sep'];
$okt			= $_POST['okt'];
$nov			= $_POST['nov'];
$des			= $_POST['des'];

$query = mysqli_query($db,"INSERT INTO absen (jan, feb, mar, apr, mei, jun, jul, aug, sep, okt, nov, des) VALUES ('$jan', '$feb', 'mar', '$apr', '$mei', '$jun', '$jul', '$aug', '$sep', $okt', $nov', '$des')");
if ($query){
	echo "<script>alert('Data Karyawan Berhasil dimasukan!'); window.location = 'absensi.php'</script>";	
} else {
	echo "<script>alert('Data Karyawan Gagal dimasukan!'); window.location = 'index.php'</script>";	
}
