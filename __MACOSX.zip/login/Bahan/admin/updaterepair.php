<?php

$con=mysqli_connect("localhost","sparksid_mainai","!Merapi14!","sparksid_mainai");
$cid         = $_POST['cid'];
$vehicle    = $_POST['vehicle'];
$year       = $_POST['year'];
$power      = $_POST['power'];
$color      = $_POST['color'];
$rep        = $_POST['rep'];
$status 	= $_POST['status'];
$date       = $_POST['date'];
$time       = $_POST['time'];

$query = mysqli_query($con, "UPDATE repairdata SET cid='$cid',vehicle='$vehicle', year='$year', power='$power', color='$color', rep='$rep', status='$status', date='$date', time='$time'WHERE cid='$cid'");
if ($query){
header('location:repairdata.php');}	
   // echo "<script>alert('Stock Losts Has Been Changed'); window.location = 'stock.php'</script>";	
//} else {
//	echo "<script>alert('Fail!'); window.location = 'edit.php?hal=edit&kd=$kary_id</script>";
//    }
?>