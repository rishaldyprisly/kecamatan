<?php
include "../koneksi.php";
$total_gaji 	= $_GET['kd'];

$query = mysqli_query($db, "DELETE FROM tb_gaji WHERE total_gaji='$total_gaji'");
if ($query){
	echo "<script>alert('Data Berhasil dihapus!'); window.location = 'tampilgajiaja.php'</script>";	
} else {
	echo "<script>alert('Data Gagal dihapus!'); window.location = 'tampilgajiaja.php'</script>";	
}
?>