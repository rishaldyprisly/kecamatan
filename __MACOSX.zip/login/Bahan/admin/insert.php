<?php
$con=mysqli_connect("localhost","sparksid_7rishy","!Merapi14!","sparksid_rishy");
$id             = $_POST['id'];
$namabarang     = $_POST['namabarang'];
$merk 		    = $_POST['merk'];
$details 	    = $_POST['details'];
$jumlah 	    = $_POST['jumlah'];
$lokasi	        = $_POST['lokasi'];

$query = mysqli_query($con, "INSERT INTO stock (id, namabarang, merk, details, jumlah, lokasi) VALUES ('$id', '$namabarang', '$merk', '$details', '$jumlah', '$lokasi')");
if ($query){
	echo "<script>alert('Stock List Added!'); window.location = 'index.php'</script>";	
} else {
	echo "<script>alert('Fail!'); window.location = 'index.php'</script>";	
}
