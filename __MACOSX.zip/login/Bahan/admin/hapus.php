<?php
$con=mysqli_connect("localhost","sparksid_mainai","!Merapi14!","sparksid_mainai");
$cid 	= $_GET['kd'];

$query = mysqli_query($con, "DELETE FROM customer WHERE cid='$cid'");
if ($query){
	echo "<script>alert('Data Has Been Deleted!'); window.location = 'index.php'</script>";	
} else {
	echo "<script>alert('Failed to delete data!'); window.location = 'index.php'</script>";	
}
?>