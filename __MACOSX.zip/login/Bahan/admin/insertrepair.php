<?php
include "../koneksi.php";

$con=mysqli_connect("localhost","sparksid_mainai","!Merapi14!","sparksid_mainai");
$cid        = $_POST['cid'];
$vehicle    = $_POST['vehicle'];
$year       = $_POST['year'];
$power      = $_POST['power'];
$color      = $_POST['color'];
$rep        = $_POST['rep'];
$status 	= $_POST['status'];
$date       = $_POST['date'];
$time       = $_POST['time'];



$query = mysqli_query($con, "INSERT INTO repairdata (cid, vehicle, year, power, color, rep, status, date, time) VALUES ('$cid', '$vehicle', '$year', '$power', '$color', '$rep', '$status', '$date', '$time')");
if ($query){
	echo "<script>alert('Repair Data Has Been Added!'); window.location = 'repairdata.php'</script>";	
} else {
	echo "<script>alert('Fail To Save Repair Data!'); window.location = 'index.php'</script>";	
}
?>