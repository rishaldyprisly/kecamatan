<?php
$con=mysqli_connect("localhost","sparksid_mainai","!Merapi14!","sparksid_mainai");
$cid         = $_POST['cid'];
$name        = $_POST['name'];
$addr        = $_POST['addr'];
$phone       = $_POST['phone'];
$vtype       = $_POST['vtype'];
$vyear       = $_POST['vyear'];
$member         = $_POST['member'];
$visit         = $_POST['visit'];
$date        = $_POST['date'];

$query = mysqli_query($con, "INSERT INTO customer (cid, name, addr, phone, vtype, vyear, member, visit, date) VALUES ('$cid', '$name', '$addr', '$phone', '$vtype', '$vyear', '$member', '$visit',  '$date')");
if ($query){
	echo "<script>alert('Stock List Added!'); window.location = 'index.php'</script>";	
} else {
	echo "<script>alert('Fail!'); window.location = 'index.php'</script>";	
}
