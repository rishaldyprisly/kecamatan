<?php 
session_start();
if (empty($_SESSION['username'])){
  date_default_timezone_set("Indonesia/Jakarta");
	echo "<script>alert('Anda belum mempunyai hak akses.'); window.location = '../index.html'</script>";	
} else {
	include "../koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Aplikasi Penggajian Karyawan">
    <meta name="author" content="Sanny Sahara">

    <title>Aplikasi Penggajian Karyawan PT.Mitra Prima Motor</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <!-- Page Specific CSS -->
    <link rel="stylesheet" href="http://cdn.oesmith.co.uk/morris-0.4.3.min.css">
    <script type="text/javascript">
    function hitung_gaji() {
var jam_lembur = document.transfer.jam_lembur.value;
var absen = document.transfer.absen.value;
var uang_lembur = document.transfer.uang_lembur.value;
var gaji_utama = document.transfer.gaji_utama.value;
var total_gaji = document.transfer.total_gaji.value;

uang_lembur = ( gaji_utama / 10 ) * jam_lembur;
document.transfer.uang_lembur.value = Math.floor( uang_lembur );

total_gaji = (gaji_utama - uang_lembur) + (2 * uang_lembur) - (100000 * absen);
document.transfer.total_gaji.value = Math.floor( total_gaji );
}
</script>
    
    <script type="text/javascript">
// 1 detik = 1000
window.setTimeout("waktu()",1000);  
function waktu() {   
	var tanggal = new Date();  
	setTimeout("waktu()",1000);  
	document.getElementById("output").innerHTML = tanggal.getHours(Indonesia/Jakarta)+":"+tanggal.getMinutes()+":"+tanggal.getSeconds();
}
</script>
<script language="JavaScript">
var tanggallengkap = new String();
var namahari = ("Minggu Senin Selasa Rabu Kamis Jumat Sabtu");
namahari = namahari.split(" ");
var namabulan = ("Januari Februari Maret April Mei Juni Juli Agustus September Oktober November Desember");
namabulan = namabulan.split(" ");
var tgl = new Date();
var hari = tgl.getDay();
var tanggal = tgl.getDate();
var bulan = tgl.getMonth();
var tahun = tgl.getFullYear();
tanggallengkap = namahari[hari] + ", " +tanggal + " " + namabulan[bulan] + " " + tahun;

	var popupWindow = null;
	function centeredPopup(url,winName,w,h,scroll){
	LeftPosition = (screen.width) ? (screen.width-w)/2 : 0;
	TopPosition = (screen.height) ? (screen.height-h)/2 : 0;
	settings ='height='+h+',width='+w+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',resizable'
	popupWindow = window.open(url,winName,settings)
}
</script>
    
  </head>
  <body>
    <div id="wrapper">

      <!-- Sidebar -->
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.html">Aplikasi Penggajian Karyawan PT.Mitra Prima Motor</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav side-nav">
          <img src="3.png" alt="right" />
            <li class="active"><a href="index.php"><i class="fa fa-dashboard"></i> Customers List</a></li>
            <li><a href="repairdata.php"><i class="fa fa-bar-chart-o"></i> Repair Data</a></li>
            
            <li><a href="status.php"><i class="fa fa-bar-chart-o"></i> Status and Condition</a></li>
            <li><a href="stock.php"><i class="fa fa-table"></i> Stock Lists</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-caret-square-o-down"></i> Information <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="info/info.html" target="_blank">Customer Special Offer</a></li>
                <li><a href="info/holiday.html" target="_blank">Holiday Time</a></li>
                <li><a href="info/meeting.html" target="_blank">Special Meeting</a></li>
                <li><a href="bcast.php" target="_blank">Massive Broadcast</a></li>
              </ul>
              </ul>
            </li>
          </ul>

          <ul class="nav navbar-nav navbar-right navbar-user">
          
            <li class="dropdown alerts-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i> Alerts <span class="badge">3</span> <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#">Default <span class="label label-default">Default</span></a></li>
                <li><a href="#">Primary <span class="label label-primary">Primary</span></a></li>
                <li><a href="#">Success <span class="label label-success">Success</span></a></li>
                <li><a href="#">Info <span class="label label-info">Info</span></a></li>
                <li><a href="#">Warning <span class="label label-warning">Warning</span></a></li>
                <li><a href="#">Danger <span class="label label-danger">Danger</span></a></li>
                <li class="divider"></li>
                <li><a href="#">View All</a></li>
              </ul>
            </li>
            <li class="dropdown user-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i>
              <?php
              echo $_SESSION['username'];
               ?>
              <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#"><i class="fa fa-user"></i> Profil</a></li>
                <li><a href="#"><i class="fa fa-envelope"></i> Pesan Masuk <span class="badge">7</span></a></li>
                <li><a href="#"><i class="fa fa-gear"></i> Pengaturan</a></li>
                <li class="divider"></li>
                <li><a href="../logout.php" onclick="return confirm('Apakah anda akan keluar?');"><i class="fa fa-power-off"></i> Keluar</a></li>
              </ul>
            </li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </nav>

<?php } ?>
      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Sallary Counter <small>Mitra Prima Motor</small></h1>
            <ol class="breadcrumb">
              <li class="active"><i class="fa fa-edit"> Insert New Car Repairment</i></li>
            </ol>
            <table width="900">
            <tr>
            <td width="250"><div class="Tanggal"><h4><script language="JavaScript">document.write(tanggallengkap);</script></div></h4></td> 
            <td align="left" width="30"> - </td>
            <td align="left" width="620"> <h4><div id="output" class="jam" ></div></h4></td>
            </tr>
            </table>
            <br />
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
             Bla bla
          </div>
        </div><!-- /.row -->
        <!-- /.row -->
        <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-edit"></i> bla bla</h3>
              </div>
              <div class="panel-body">
                 <div class="table-responsive">
                  
                  <?php
$con=mysqli_connect("localhost","sparksid_mainai","!Merapi14!","sparksid_mainai");
$query = mysqli_query($con, "SELECT * FROM customer WHERE cid='$_GET[kd]'");
$data  = mysqli_fetch_array($query);
?>
    <form action="insertrepair.php" method="post" autocomplete="off" name="transfer">
    <table class="table table-condensed">
   
   
      <tr>
        <td><label for="cid">Customer ID</label></td>
        <td><input name="cid" type="text" class="form-control" id="cid" value="<?php echo $data['cid'];?>"  readonly="readonly"/></td>
      </tr>
      
       <tr>
        <td><label for="vehicle">Vehicle</label></td>
        <td><select name="vehicle" name="vehicle" id="vehicle" class="form-control" required>
<option></option>
<option value="Aston Martin">Aston Martin</option>
<option value="BMW">BMW</option>
<option value="Daihatsu">Daihatsu</option>
<option value="Honda">Honda</option>
<option value="Toyota">Toyota</option>
<option value="Tata">Tata</option>
<option value="Suzuki">Suzuki</option>
<option value="Lamborghini">Lamborghini</option>
<option value="Proton">Proton</option>
<option value="Lexus">Lexus</option>
<option value="Mitsubishi">Mitsubishi</option>
</select></td>
      </tr>
      
       <tr>
        <td><label for="year">Year</label></td>
        <td><input name="year" type="text" class="form-control" id="year" value="<?php echo $data['year'];?>"  required/></td>
      </tr>
      
       <tr>
        <td><label for="power">Power</label></td>
        <td><input name="power" type="text" class="form-control" id="power" value="<?php echo $data['power'];?>"  required/></td>
      </tr>
       <tr>
        <td><label for="color">Color</label></td>
        <td><input name="color" type="text" class="form-control" id="color" value="<?php echo $data['color'];?>"  required/></td>
      </tr>
     
      <tr>
        <td><label for="rep">Replacement</label></td>
        <td><input name="rep" type="text" class="form-control" id="rep" value="<?php echo $data['rep'];?>"  required/></td>
      </tr>
      </tr>
      <tr>
        <td><label for="status">Status</label></td>
        <td><input name="status" type="text" class="form-control" id="status" value="<?php echo $data['status'];?>" required/></td>
      </tr> 
      <tr>
        <td><label for="owner">Owner</label></td>
        <td><input name="owner" type="text" class="form-control" id="owner" value="<?php echo $data['name'];?>" readonly="readonly"/></td>
      </tr>
      <tr>
        <td><label for="phone">Phone Number</label></td>
        <td><input name="phone" type="text" class="form-control" id="phone" value="<?php echo $data['phone'];?>" readonly="readonly"/></td>
      </tr> 
      
      <tr>
        <td><label for="date">Date Entered</label></td>
        <td><input name="date" type="text" class="form-control" id="date" value="<?php echo "".date("Y-m-d").""; ?>" required/></td>
      </tr>
      <tr>
        <td><label for="time">Time Entered</label></td>
        <td><input name="time" type="text" class="form-control" id="time" value="<?php echo "".date("H:i:sa").""?>" required/></td>
      </tr>
      <tr>
        <td><input type="submit" value="Save"  class="btn btn-sm btn-primary"/>&nbsp;<a href="index.php" class="btn btn-sm btn-primary">Back</a></td>
        </tr>
    </table>
    </form>
                   </div>
                 <div class="text-right">
                  
              
                </div>
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 
      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

    <!-- Page Specific Plugins -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="js/morris/chart-data-morris.js"></script>
    <script src="js/tablesorter/jquery.tablesorter.js"></script>
    <script src="js/tablesorter/tables.js"></script>

  </body>
</html>
