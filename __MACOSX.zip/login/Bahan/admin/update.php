<?php

$con=mysqli_connect("localhost","sparksid_7rishy","!Merapi14!","sparksid_rishy");
$id             = $_POST['id'];
$namabarang     = $_POST['namabarang'];
$merk 		    = $_POST['merk'];
$details		= $_POST['details'];
$jumlah 	    = $_POST['jumlah'];
$lokasi	        = $_POST['lokasi'];

$query = mysqli_query($con, "UPDATE stock SET id='$id',namabarang='$namabarang', merk='$merk', details='$details', jumlah='$jumlah', lokasi='$lokasi' WHERE id='$id'");
if ($query){
header('location:stock.php');}	
   // echo "<script>alert('Stock Losts Has Been Changed'); window.location = 'stock.php'</script>";	
//} else {
//	echo "<script>alert('Fail!'); window.location = 'edit.php?hal=edit&kd=$kary_id</script>";
//    }
?>