
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="Images/1.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Kecamatan Curug
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="azure" data-background-color="white" data-image="assets/img/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-normal">
          Kecamatan Curug
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
         
                   <li class="nav-item  ">
            <a class="nav-link" href="index.php">
              <i class="material-icons">dashboard</i>
              <p>Home</p>
            </a>
          </li>
          
          <li class="nav-item active">
            <a class="nav-link" href="pertanyaan.php">
              <i class="material-icons">person</i>
              <p>Bantuan</p>
            </a>
          </li>
          <li class="nav-item dropdown">
                <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="material-icons">library_books</i>
                  <span class="notification">Prosedur</span>
                  <p class="d-lg-none d-md-block">
                    Some Actions
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="akta.php">Prosedur Akta Kelahiran</a>
                  <a class="dropdown-item" href="ktp.php">Prosedur KTP</a>
                  <a class="dropdown-item" href="kk.php">Prosedur Kartu Keluarga</a>
                  <a class="dropdown-item" href="masuk.php">Surat Pindah Masuk</a>
                  <a class="dropdown-item" href="keluar.php">Surat Pindah Keluar</a>
                  <a class="dropdown-item" href="mati.php">Akta Kematian</a>
                </div>
              </li>
          <!-- li class="nav-item ">
            <a class="nav-link" href="akta.php">
              <i class="material-icons">library_books</i>
              <p>Prosedur Akta Kelahiran</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="ktp.php">
              <i class="material-icons">library_books</i>
              <p>Prosedur KTP</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="kk.php">
              <i class="material-icons">library_books</i>
              <p>Kartu Keluarga</p>
            </a>
            
           <li class="nav-item">
            <a class="nav-link" href="masuk.php">
              <i class="material-icons">library_books</i>
              <p>Surat Pindah Masuk</p>
            </a>
          </li>
          
           <li class="nav-item">
            <a class="nav-link" href="keluar.php">
              <i class="material-icons">library_books</i>
              <p>Surat Pindah Keluar</p>
            </a>
          </li>
          
           <li class="nav-item">
            <a class="nav-link" href="mati.php">
              <i class="material-icons">library_books</i>
              <p>Akta Kematian</p>
            </a>
          </li>
          
          
          -->
          
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="#pablo">Formulir</a>
          </div>
          </br>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <form class="navbar-form">
              <div class="input-group no-border">
                <input type="text" value="" class="form-control" placeholder="Search...">
                <button type="submit" class="btn btn-white btn-round btn-just-icon">
                  <i class="material-icons">search</i>
                  <div class="ripple-container"></div>
                </button>
              </div>
            </form>
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="#pablo">
                  <i class="material-icons">dashboard</i>
                  <p class="d-lg-none d-md-block">
                    Stats
                  </p>
                </a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="material-icons">notifications</i>
                  <span class="notification">5</span>
                  <p class="d-lg-none d-md-block">
                    Some Actions
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="#">Mike John responded to your email</a>
                  <a class="dropdown-item" href="#">You have 5 new tasks</a>
                  <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                  <a class="dropdown-item" href="#">Another Notification</a>
                  <a class="dropdown-item" href="#">Another One</a>
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#pablo">
                  <i class="material-icons">person</i>
                  <p class="d-lg-none d-md-block">
                    Account
                  </p>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
 <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Formulir Pengaduan</h4>
                  <p class="card-category">Mohon Isi Formulir Dengan Data Yang Benar</p>
                </div>
                <div class="card-body">
                  <form action="push.php" method="post">
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">NAMA</label>
                          <input type="text" name="NAME" class="form-control" id="NAME" value="">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">ALAMAT</label>
                          <input type="text" name="ADDRESS" class="form-control" id="ADDRESS" value="">
                        </div>
                      </div>
                     
                      
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">NIK SESUAI KK</label>
                          <input type="text" name="NIK_KK" class="form-control" id="NIK_KK" value="">
                        </div>
                      </div>
                      </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">NIK KTP SEBELUMNYA</label>
                          <input type="text"name="NIK_KTP"  class="form-control" id="NIK_KTP" value="">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">PHONE</label>
                          <input type="text" name="PHONE" class="form-control" id="PHONE" value="">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">JENIS KELAMIN</label>
                          <input type="text" name="GENDER" class="form-control" id="GENDER" value="">
                        </div>
                      </div>
                     

                    </div>
                    <div class="row">
                       <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">SUBJECT  | ISI SESUAI TOPIK YANG ANDA INGINKAN : KTP/KK/AKTA KELAHIRAN/AKTA KEMATIAN/SURAT PINDAH MASUK/SURAT PINDAH KELUAR/AHLI WARIS</label>
                          <input type="text" name="SUBJECT"  class="form-control" id="SUBJECT" value="">
                        </div>
                      </div>
                      
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">MESSAGES</label>
                          <input type="text" name="MESSAGES"  class="form-control" id="MESSAGES" value="">
                        </div>
                      </div>
                      
                      
                    </div>
                    
                   
                    
                    <button type="submit" class="btn btn-primary pull-right">KIRIM PESAN</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card card-profile">
                <div class="card-avatar">
                  <a href="#pablo">
                    <img class="img" src="Images/1.png" >
                  </a>
                </div>
                <div class="card-body">               
                  <h4 class="card-title text-black">KECAMATAN CURUG</h4>
                  <p class="card-description">
                    Kecamatan Curug merupakan salah satu Kantor Kecamatan di Wilayah Kabupaten Tangerang yang memiliki luas wilayah +2.921,38 Ha, berpenduduk 173.914 jiwa dengan kepadatan +60 jiwa/Ha. Kecamatan Curug mempunyai wilayah pemerintahan sebanyak 3 Kelurahan dan 4 Desa yaitu Kelurahan Binong, Kelurahan Curug Kulon, Kelurahan Sukabakti, Desa Cukanggalih, Desa Curug Wetan, Desa Kadu, dan Desa Kadu Jaya.
                  </p>
               
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
          <footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
            <ul>
              <li>
                <a href="https://sleekwave.net">
                  Creative Tim
                </a>
              </li>
              <li>
                <a href="https://sleekwave.net">
                  About Us
                </a>
              </li>
              <li>
                <a href="http://sleekwave.net">
                  FAQ
                </a>
              </li>
              <li>
                <a href="https://sleekwave.net">
                  Licenses
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, Made with <i class="material-icons">LOVE</i> by
            <a href="https://sleekwave.net" target="_blank">Istiana</a>- 2019
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="assets/js/core/jquery.min.js" type="text/javascript"></script>
  <script src="assets/js/core/popper.min.js" type="text/javascript"></script>
  <script src="assets/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chartist JS -->
  <script src="assets/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="assets/js/material-dashboard.min.js?v=2.1.0" type="text/javascript"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="assets/demo/demo.js"></script>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      md.initDashboardPageCharts();

    });
  </script>
</body>

</html>