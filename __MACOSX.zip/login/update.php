<?php

$con=mysqli_connect("localhost","sleekwav_storage","Merapi14","sleekwav_lumba");

$ID             = $_POST['ID'];
$NAME           = $_POST['NAME'];
$ADDRESS        = $_POST['ADDRESS'];
$PHONE          = $_POST['PHONE'];
$DIVISION       = $_POST['DIVISION'];
$EMAIL          = $_POST['EMAIL'];
$ROLE           = $_POST['ROLE'];
$INFORMATION    = $_POST['INFORMATION'];
$MAC            = $_POST['MAC'];

$query = mysqli_query($con, "UPDATE Employee SET NAME='$NAME', ADDRESS='$ADDRESS', PHONE='$PHONE', DIVISION='$DIVISION', EMAIL='$EMAIL', ROLE='$ROLE', INFORMATION='$INFORMATION', MAC='$MAC' WHERE ID='$ID'");
if ($query){

    echo "<script>alert('Employee Data Has Been Changed'); window.location = 'employee.php'</script>";	
} else {
	echo "<script>alert('Fail!'); window.location = 'edit.php?hal=edit&kd='employee.php'</script>";
    }
?>