
                     <?php

                    $ch = curl_init();
                    $fields = array( 'msisdn'=>"+082310707768", 'content'=>"Pengaduan dan pertanyaan anda sudah diterima oleh pegawai kami. Mohon menunggu informasi selanjutnya. ");
                    $postvars = '';
                    foreach($fields as $key=>$value) {
                    $postvars .= $key . "=" . $value . "&";
                    }
                     $url = "https://api.mainapi.net/smsnotification/1.0.0/messages";
                     curl_setopt($ch,CURLOPT_URL,$url);
                     curl_setopt($ch,CURLOPT_POST, 1);                //0 for a get request
                     curl_setopt($ch,CURLOPT_POSTFIELDS,$postvars);
                     curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
                     curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,3);
                     curl_setopt($ch,CURLOPT_TIMEOUT, 20);
                     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                     curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                     curl_setopt($ch,CURLOPT_HTTPHEADER,array("Authorization: Bearer 749d10b3580235d3156c0f6acb67a6c1"));
                    $response = curl_exec($ch);
                    curl_close ($ch);
                    ?>
                 