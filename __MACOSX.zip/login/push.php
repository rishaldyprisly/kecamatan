<?php

$con=mysqli_connect("localhost","sleekwav_user","Merapi14","sleekwav_kec");


$NAME           	= $_POST['NAME'];
$ADDRESS        	= $_POST['ADDRESS'];
$NIK_KK				= $_POST['NIK_KK'];
$NIK_KTP            = $_POST['NIK_KTP'];
$PHONE				= $_POST['PHONE'];
$GENDER				= $_POST['GENDER'];
$SUBJECT				= $_POST['SUBJECT'];
$MESSAGES		= $_POST['MESSAGES'];


$query = mysqli_query($con, "INSERT INTO public (NAME, ADDRESS, NIK_KK, NIK_KTP, PHONE, GENDER, SUBJECT, MESSAGES)VALUES ('$NAME', '$ADDRESS', '$NIK_KK', '$NIK_KTP', '$PHONE', '$GENDER', '$SUBJECT', '$MESSAGES')");


if ($query){

    echo "<script>alert('Pengaduan terkirim! Mohon menunggu SMS untuk informasi selanjutnya'); window.location = 'index.php'</script>";	
} else {
	echo "<script>alert('Pengaduan Gagal! Salah Satu Data Anda Tidak Valid'); window.location = 'index.php'</script>";
    }
?>
