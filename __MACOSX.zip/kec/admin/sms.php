<?php 
 
// Update the path below to your autoload.php, 
// see https://getcomposer.org/doc/01-basic-usage.md 
require_once '/Twilio/autoload.php'; 
 
use Twilio\Rest\Client; 


                     $con=mysqli_connect("localhost","sleekwav_user","Merapi14","sleekwav_kec");
                     $result = mysqli_query($con,"SELECT * FROM public WHERE PHONE='$_GET[kd]'");

 
$sid    = "AC316a91c35873d13ccfe5ef2f82027148"; 
$token  = "f6e9acb123240750f85ae70a804c3f22"; 
$twilio = new Client($sid, $token); 
 
$message = $twilio->messages 
                  ->create("+6285772259593", // to 
                           array( 
                               "from" => "+14172813698",       
                               "body" => "Hallo! Pengaduan dan pertanyaan anda sudah diterima oleh pegawai Kecamatan Curug. Mohon menunggu informasi selanjutnya." 
                           ) 
                  ); 
 
print($message->sid);